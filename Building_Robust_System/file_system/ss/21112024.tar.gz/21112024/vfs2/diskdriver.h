#include "vdc.h"

int d;