// READ ME

- I am done programming related disk creation and file insert in vfs1 folder
- Then related disk creation and bitmap related programming in vfs2 folder
- But sir I made various changes in program so I comment out the program so it didn't work properly of folder vfs1
- Only disk creation part working in both folders
- So I don't write how to run the program fully
- But I am writing to run for disk creation in vfs2 folder as follows ->

	- first create a.out file with command -> gcc vdc.c -lm
	- then run with command -> ./a.out <diskname> <size_of_disk> <M/G> <size_of_block> <B/K>